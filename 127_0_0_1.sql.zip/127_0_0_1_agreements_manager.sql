-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 27 Mar 2023, 19:51
-- Wersja serwera: 10.4.24-MariaDB
-- Wersja PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `agreements_manager`
--
CREATE DATABASE IF NOT EXISTS `agreements_manager` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `agreements_manager`;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `agreements`
--

CREATE TABLE `agreements` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT uuid(),
  `institutionName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `institutionCity` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `institutionStreet` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `institutionZipCode` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personForContact` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personForContactMail` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personForContactPhone` int(9) DEFAULT NULL,
  `responseDate` date DEFAULT NULL,
  `offerSendingDate` date DEFAULT NULL,
  `agreementNo` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agreementStartDate` date DEFAULT NULL,
  `agreementEndDate` date DEFAULT NULL,
  `employeeId1` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employeeId2` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `executionDate` date DEFAULT NULL,
  `reportId` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportDate` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoiceAmount` float(8,2) DEFAULT NULL,
  `invoiceDate` date DEFAULT NULL,
  `notes` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `agreements`
--

INSERT INTO `agreements` (`id`, `institutionName`, `institutionCity`, `institutionStreet`, `institutionZipCode`, `personForContact`, `personForContactMail`, `personForContactPhone`, `responseDate`, `offerSendingDate`, `agreementNo`, `agreementStartDate`, `agreementEndDate`, `employeeId1`, `employeeId2`, `executionDate`, `reportId`, `reportDate`, `invoiceAmount`, `invoiceDate`, `notes`) VALUES
('123', 'CKD', 'Lodz', 'pomorska 100', '91-300', 'Jan Nowak', 'jan.nowak@ab.ab', 789456123, '2023-03-26', '2023-03-29', '1234/2314/0000/hsgtranjksy/hdg', '2023-03-30', '2023-04-16', '1bf3ca53-9389-407b-b545-c36d25970a72', '20e9de32-e169-4345-b7e2-2b4d18151293', '2023-04-08', 'cd/da/2135/gsddres-2', '2023-04-11', 8000.00, '2023-04-12', '5 satnowisk; 6 substancji;'),
('456', 'imp', 'Waw', 'hgw', '10-200', 'olek', 'krzyś', 895632145, '2023-03-27', '2023-03-27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `employees`
--

CREATE TABLE `employees` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT uuid(),
  `firstName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `employees`
--

INSERT INTO `employees` (`id`, `firstName`, `lastName`, `email`, `phone`) VALUES
('1bf3ca53-9389-407b-b545-c36d25970a72', 'Lena', 'Leno', 'lena@haja.kl', '658945632'),
('20e9de32-e169-4345-b7e2-2b4d18151293', 'Zofia', 'hdf', 'BHUg@bg.oj', '654987321'),
('91d7b44c-afa4-4320-b009-f9d423c259c7', '2023-03-08', 'dodac', 'fjul@jdhgd', '568944568'),
('b9893f3d-bdd5-4ec0-bf58-5930972a4e78', '2023-03-14', 'krok', 'fjul@jdhgd', '987456321'),
('fdd7d70c-9db4-4659-8198-d9125be3307d', 'gsfsf', 'hdgdg', 'gdgdg@hdgh.pl', '798789788');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `agreements`
--
ALTER TABLE `agreements`
  ADD KEY `employeeId1` (`employeeId1`) USING BTREE,
  ADD KEY `employeeId2` (`employeeId2`);

--
-- Indeksy dla tabeli `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `agreements`
--
ALTER TABLE `agreements`
  ADD CONSTRAINT `FK_agreements_employees` FOREIGN KEY (`employeeId1`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_agreements_employees_2` FOREIGN KEY (`employeeId2`) REFERENCES `employees` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
